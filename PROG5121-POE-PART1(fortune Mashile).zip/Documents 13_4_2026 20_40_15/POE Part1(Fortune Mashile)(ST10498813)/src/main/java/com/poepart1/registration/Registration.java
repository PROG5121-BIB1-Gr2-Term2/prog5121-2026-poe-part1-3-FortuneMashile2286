/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.poepart1.registration;

/**
 *
 * @author fortune
 */
import javax.swing.JOptionPane;
public class Registration {

  //Declaring variables  
    private String username;
    private String password;
    private String cellNumber;
    private String firstName;
    private String lastName;

    public static void main(String[] args) {
//Calling in method
        Registration reg = new Registration();
        reg.registerUser();

        Login login = new Login(
                reg.username,
                reg.password,
                reg.cellNumber,
                reg.firstName,
                reg.lastName
        );

        login.startLogin();
    }

    public void registerUser() {
//Prommpting the user to enter details and also looping 

        firstName = JOptionPane.showInputDialog("Enter first name:");
        lastName = JOptionPane.showInputDialog("Enter last name:");

        username = JOptionPane.showInputDialog("Enter username:");
        while (!checkUsername(username)) {
            JOptionPane.showMessageDialog(null, "Username must contain '_' and be max 5 characters.");
            username = JOptionPane.showInputDialog("Enter username:");
        }

        password = JOptionPane.showInputDialog("Enter password:");
        while (!checkPassword(password)) {
            JOptionPane.showMessageDialog(null, "Password must be 8+ chars with capital, number & symbol.");
            password = JOptionPane.showInputDialog("Enter password:");
        }

        cellNumber = JOptionPane.showInputDialog("Enter cell number:");
        while (!checkcellNumber(cellNumber)) {
            JOptionPane.showMessageDialog(null, "Cell must start with +27.");
            cellNumber = JOptionPane.showInputDialog("Enter cell number:");
        }

        JOptionPane.showMessageDialog(null, "Registration successful!");
    }
//Checking if the usere met the requirements
    public static boolean checkUsername(String user) {
        return user.contains("_") && user.length() <= 5;
    }
//using if statements to check conditions
    public static boolean checkPassword(String pass) {
        if (pass.length() < 8) return false;

        boolean hasCap = false, hasNum = false, hasSpec = false;

        for (char c : pass.toCharArray()) {
            if (Character.isUpperCase(c)) hasCap = true;
            else if (Character.isDigit(c)) hasNum = true;
            else if (!Character.isLetterOrDigit(c)) hasSpec = true;
        }

        return hasCap && hasNum && hasSpec;
    }

    public static boolean checkcellNumber(String phone) {
        return phone.startsWith("+27");
    }
}

    

