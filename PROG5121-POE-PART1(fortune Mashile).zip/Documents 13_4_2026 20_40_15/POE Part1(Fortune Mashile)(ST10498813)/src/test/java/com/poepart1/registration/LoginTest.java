/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.poepart1.registration;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author fortune
 */
public class LoginTest {


    // ===== USERNAME TESTS =====

    @Test
    public void testCheckUserName_Valid() {
        Login log = new Login("kyl_1", "Password1!", "+27838968976", "Kyle", "Smith");
        assertTrue(log.checkUserName("kyl_1"));
    }

    @Test
    public void testCheckUserName_Invalid() {
        Login log = new Login("kyl_1", "Password1!", "+27838968976", "Kyle", "Smith");
        assertFalse(log.checkUserName("kyle")); // no underscore
    }

    // ===== PASSWORD TESTS =====

    @Test
    public void testPassword_Valid() {
        Login log = new Login("kyl_1", "Password1!", "+27838968976", "Kyle", "Smith");
        assertTrue(log.checkPasswordComplexity("Password1!"));
    }

    @Test
    public void testPassword_Invalid() {
        Login log = new Login("kyl_1", "Password1!", "+27838968976", "Kyle", "Smith");
        assertFalse(log.checkPasswordComplexity("pass")); // too weak
    }

    // ===== CELL NUMBER TESTS =====

    @Test
    public void testCell_Valid() {
        Login log = new Login("kyl_1", "Password1!", "+27838968976", "Kyle", "Smith");
        assertTrue(log.checkCellPhoneNumber("+27838968976"));
    }

    @Test
    public void testCell_Invalid() {
        Login log = new Login("kyl_1", "Password1!", "+27838968976", "Kyle", "Smith");
        assertFalse(log.checkCellPhoneNumber("0838968976")); // missing +27
    }
}