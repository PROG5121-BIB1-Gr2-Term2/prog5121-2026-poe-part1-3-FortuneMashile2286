/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.poepart1.registration;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author fortune
 */
public class RegistrationTest {
    

    // ===== USERNAME TESTS =====

    @Test
    public void testCheckUsername_Valid() {
        assertTrue(Registration.checkUsername("abc_1"));
    }

    @Test
    public void testCheckUsername_Invalid() {
        assertFalse(Registration.checkUsername("abcdef")); // no underscore + too long
    }

    // ===== PASSWORD TESTS =====

    @Test
    public void testCheckPassword_Valid() {
        assertTrue(Registration.checkPassword("Passw0rd!"));
    }

    @Test
    public void testCheckPassword_Invalid() {
        assertFalse(Registration.checkPassword("pass")); // too short + no rules met
    }

    // ===== CELL NUMBER TESTS =====

    @Test
    public void testCheckCell_Valid() {
        assertTrue(Registration.checkcellNumber("+27838968976"));
    }

    @Test
    public void testCheckCell_Invalid() {
        assertFalse(Registration.checkcellNumber("0838968976")); // no +27
    }
}